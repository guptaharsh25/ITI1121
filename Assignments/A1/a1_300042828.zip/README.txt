Name: Harsh Gupta ~~ NO PARTNER ~~
Student #: 300042828
E-mail: hgupt033@uottawa.ca

Course: ITI 1121
Section: C
Assignment #: 1

This directory includes java files for executing linear regression using the gradient descent method for any (natural) number of variables.

This assignment was fun.