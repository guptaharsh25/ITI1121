Assignment 4 Submission
Section C

Student 1 Name: Harsh Gupta
Student 1 No.: 300042828

Student 2 Name: Harsh Gupta
Student 2 No.: 300042828

This assignment solves various problems and methods for LinkedLists, Iterators and BinarySearchTrees.